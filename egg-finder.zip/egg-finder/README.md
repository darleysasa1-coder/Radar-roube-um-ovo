# Egg Finder Pro (Roube um Ovo, Place ID 107778070777162)

## Instalação no Quetta (Android)
1. Compacte esta pasta em `egg-finder.zip` (já incluso) e descompacte no aparelho.
2. Abra `quetta://extensions`, ative o Modo do desenvolvedor.
3. Toque em "Carregar sem compactação" e escolha a pasta `egg-finder` (a que contém manifest.json).
4. Toque no ícone da extensão: o app abre em uma aba. Requer o app Roblox instalado para o JOIN.
Se a sua versão do Quetta não carregar extensões descompactadas, o mesmo código roda no Chrome/Edge do PC.

## O que funciona sem nenhuma fonte externa
Server Hop, histórico, favoritos, ajustes, verificação e entrada em servidores reais (API pública games.roblox.com).

## Finder: formato da fonte (JSON via https)
O Roblox não expõe publicamente mascotes por servidor. Use uma fonte autorizada (API oficial do desenvolvedor do jogo ou um serviço de terceiros com permissão) que retorne uma lista:
[{"jobId":"<uuid do servidor>","name":"Celestial Sunlion","gen":69500000000,"size":4.15,"rarity":"Legendary","mutation":"GLD","foundAt":1760000000,"image":"https://..."}]
Itens sem jobId UUID válido, nome ou gen numérico são descartados. Sem foundAt, usa-se o momento em que o item chegou.
