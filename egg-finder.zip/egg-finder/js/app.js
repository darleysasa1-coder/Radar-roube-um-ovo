"use strict";
const PLACE="107778070777162",API=`https://games.roblox.com/v1/games/${PLACE}/servers/Public`;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const DEF={feedUrl:"",refresh:15,perPage:30,auto:true,notify:true,minGen:"0",minSize:0,ttl:600,rarityOrder:"Common,Uncommon,Rare,Epic,Legendary,Mythic,Secret",hopMin:1,hopMax:1,hopEvery:10};
const FIELDS=[["feedUrl","URL da fonte de dados (JSON, https)","text"],["refresh","Intervalo de atualização (s)","number"],["perPage","Resultados por página","number"],["minGen","Rendimento mínimo desejado (ex.: 10M)","text"],["minSize","Multiplicador mínimo (x)","number"],["rarityOrder","Ordem de raridade (menor para maior)","text"],["ttl","Expirar resultados após (s)","number"],["hopMin","Hop: jogadores mínimos","number"],["hopMax","Hop: jogadores máximos","number"],["hopEvery","Hop: intervalo automático (s)","number"],["auto","Atualização automática","checkbox"],["notify","Notificações visuais","checkbox"]];
let S={cfg:{...DEF},fav:[],hist:[],visited:[]};
const store={async load(){const r=await chrome.storage.local.get("s");if(r.s)S={...S,...r.s,cfg:{...DEF,...r.s.cfg}}},save(){return chrome.storage.local.set({s:S})}};
const items=new Map(),F={sort:"gen",dir:-1},rarSel=new Set();let page=1,running=false,timer=null,hopT=null,rarKey="";
const lastJoin={};
const parseNum=v=>{const m=String(v??"").trim().toLowerCase().replace(",",".").match(/^([\d.]+)\s*([kmbt])?$/);return m?parseFloat(m[1])*({k:1e3,m:1e6,b:1e9,t:1e12}[m[2]]||1):0};
const fmt=n=>{for(const[v,s]of[[1e12,"T"],[1e9,"B"],[1e6,"M"],[1e3,"K"]])if(n>=v)return +(n/v).toFixed(2)+s;return ""+Math.round(n)};
const age=t=>{const s=Math.max(0,(Date.now()-t)/1000|0);return s<60?s+"s":s<3600?(s/60|0)+"m":(s/3600|0)+"h"};
const order=()=>S.cfg.rarityOrder.split(",").map(s=>s.trim().toLowerCase()).filter(Boolean);
const rank=r=>order().indexOf(String(r).toLowerCase())+1;
const isRare=i=>{const n=order().length;return n>0&&rank(i.rarity)>n-3};
let tt;function toast(m){const e=$("#toast");e.textContent=m;e.style.display="block";clearTimeout(tt);tt=setTimeout(()=>e.style.display="none",4000)}
function setLive(t){$("#liveTxt").textContent=t;$("#live").classList.toggle("on",t==="buscando")}

async function jf(url,opt){for(let i=0;i<3;i++){const r=await fetch(url,opt);if(r.status===429){await sleep(1500*(i+1));continue}if(!r.ok)throw new Error("HTTP "+r.status);return r.json()}throw new Error("Limite de requisições (429). Aguarde um pouco.")}
const q=c=>c?`&cursor=${encodeURIComponent(c)}`:"";
async function servers(pages){let out=[],c="";for(let p=0;p<pages;p++){const d=await jf(`${API}?sortOrder=Asc&limit=100&excludeFullGames=true${q(c)}`);out.push(...d.data);c=d.nextPageCursor;if(!c)break}return out}
async function check(id){let c="";for(let p=0;p<6;p++){const d=await jf(`${API}?sortOrder=Desc&limit=100${q(c)}`);const s=d.data.find(x=>x.id===id);if(s)return s.playing>=s.maxPlayers?"full":"ok";c=d.nextPageCursor;if(!c)return"gone"}return"unknown"}
function launch(id){const a=document.createElement("a");a.href=`roblox://experiences/start?placeId=${PLACE}&gameInstanceId=${id}`;document.body.appendChild(a);a.click();a.remove()}

async function join(jobId,name){
 if(Date.now()-(lastJoin[jobId]||0)<20000)return toast("Você já tentou este servidor há pouco. Aguarde.");
 lastJoin[jobId]=Date.now();toast("Verificando servidor…");
 try{const st=await check(jobId);
  if(st==="gone")return toast("Servidor indisponível: já foi encerrado.");
  if(st==="full")return toast("Servidor cheio. Tente outro resultado.");
  toast(st==="ok"?"Abrindo o Roblox…":"Não foi possível confirmar o servidor. Tentando abrir mesmo assim…")
 }catch(e){toast("Verificação falhou ("+e.message+"). Tentando abrir mesmo assim…")}
 S.hist.unshift({t:Date.now(),type:"join",name:name||"",jobId});if(!S.visited.includes(jobId))S.visited.push(jobId);S.hist.length=Math.min(S.hist.length,300);store.save();launch(jobId)}

function norm(r){if(!r||typeof r!=="object")return null;const jobId=String(r.jobId||r.serverId||""),gen=Number(r.gen??r.generation);
 if(!/^[0-9a-f-]{36}$/i.test(jobId)||!r.name||!isFinite(gen))return null;let t=Number(r.foundAt);if(t&&t<1e12)t*=1000;
 return{jobId,name:String(r.name),gen,size:Number(r.size)||1,rarity:String(r.rarity||""),mut:String(r.mutation||r.mut||""),image:/^https:\/\//.test(r.image||"")?r.image:"",foundAt:t||Date.now()}}
async function pull(){
 if(!S.cfg.feedUrl){renderList();return}
 try{const d=await jf(S.cfg.feedUrl,{cache:"no-store"}),arr=Array.isArray(d)?d:d.results;if(!Array.isArray(arr))throw new Error("JSON inválido: esperado uma lista");
  let fresh=0;for(const r of arr){const it=norm(r);if(!it)continue;it.key=`${it.jobId}|${it.name}|${it.gen}`;
   if(!items.has(it.key)){it.isNew=true;items.set(it.key,it);fresh++;S.hist.unshift({t:Date.now(),type:"find",name:`${it.name} ${fmt(it.gen)}/s`,jobId:it.jobId})}}
  const lim=Date.now()-S.cfg.ttl*1000;for(const[k,v]of items)if(v.foundAt<lim)items.delete(k);
  S.hist.length=Math.min(S.hist.length,300);store.save();if(fresh&&S.cfg.notify)toast(fresh+" novo(s) resultado(s)")
 }catch(e){toast("Erro na busca: "+e.message)}
 renderList()}
async function tick(){if(!running)return;await pull();if(!running)return;if(S.cfg.auto)timer=setTimeout(tick,Math.max(5,S.cfg.refresh)*1000);else{running=false;setLive("parado")}}
function start(){if(running)return;running=true;setLive("buscando");tick()}
function pause(){running=false;clearTimeout(timer);setLive("pausado")}

function view(){const b=parseNum($("#fMax").value),mg=Math.max(parseNum($("#fMin").value),parseNum(S.cfg.minGen)),ms=Math.max(Number($("#fSize").value)||0,Number(S.cfg.minSize)||0),ex=Number($("#fExact").value)||0,ag=Number($("#fAge").value)||0,nm=$("#fName").value.trim().toLowerCase(),now=Date.now();
 const k={gen:i=>i.gen,size:i=>i.size,recent:i=>i.foundAt,rarity:i=>rank(i.rarity)*1e15+i.gen}[F.sort];
 return[...items.values()].filter(i=>i.gen>=mg&&(!b||i.gen<=b)&&i.size>=ms&&(!ex||Math.abs(i.size-ex)<.005)&&(!ag||now-i.foundAt<=ag*1000)&&(!nm||i.name.toLowerCase().includes(nm))&&(!rarSel.size||rarSel.has(i.rarity))).sort((x,y)=>(k(x)-k(y))*F.dir)}
function card(i){const fav=S.fav.some(f=>f.key===i.key);
 return`<div class="card ${isRare(i)?"rare":""} ${i.isNew?"new":""}"><div class="img">${i.image?`<img src="${esc(i.image)}" loading="lazy" alt="">`:"🥚"}</div><div><div class="nm">${esc(i.name)}</div><div class="meta"><b>${fmt(i.gen)}/s</b> | ${esc(i.mut||"sem mutação")} | <span data-t="${i.foundAt}">${age(i.foundAt)}</span> | x${i.size}</div><div class="meta"><em>${esc(i.rarity||"sem raridade")}</em> — servidor ${esc(i.jobId.slice(0,8))}</div></div><div class="act"><button class="btn" data-join="${esc(i.key)}">JOIN</button><button class="star ${fav?"on":""}" data-fav="${esc(i.key)}" aria-label="Favoritar">${fav?"★":"☆"}</button></div></div>`}
function renderList(){const r=view(),n=Math.max(5,S.cfg.perPage)*page;$("#count").textContent=r.length+" resultado(s)";
 $("#list").innerHTML=r.length?r.slice(0,n).map(card).join(""):`<div class="empty">${S.cfg.feedUrl?"<b>Nenhum resultado</b> com os filtros atuais. Aguarde a próxima atualização ou afrouxe os filtros.":"<b>Nenhuma fonte de mascotes configurada.</b> O Roblox não publica quais mascotes existem em cada servidor, então o Finder precisa de uma fonte autorizada. Informe a URL em Ajustes (formato no README). Enquanto isso, o Server Hop já funciona."}</div>`;
 r.forEach(i=>delete i.isNew);$("#more").hidden=r.length<=n;drawRar()}
function drawRar(){const rs=[...new Set([...items.values()].map(i=>i.rarity).filter(Boolean))].sort((a,b)=>rank(b)-rank(a)),k=rs.join();if(k===rarKey)return;rarKey=k;
 $("#fRar").innerHTML=rs.map(x=>`<button class="chip ${rarSel.has(x)?"on":""}" data-rar="${esc(x)}">${esc(x)}</button>`).join("")}
function drawFav(){$("#favList").innerHTML=S.fav.length?S.fav.map(card).join(""):`<div class="empty"><b>Sem favoritos.</b> Toque na estrela de um resultado para salvá-lo aqui.</div>`}
function drawHist(){const L={find:"Encontrado",join:"Entrada",hop:"Hop"};$("#histList").innerHTML=S.hist.length?S.hist.slice(0,100).map(h=>`<div class="card" style="grid-template-columns:1fr auto"><div><div class="nm">${L[h.type]}: ${esc(h.name||"servidor")}</div><div class="meta">${new Date(h.t).toLocaleString()} — ${esc(h.jobId.slice(0,8))}</div></div><button class="btn alt" data-joinid="${esc(h.jobId)}">JOIN</button></div>`).join(""):`<div class="empty"><b>Histórico vazio.</b></div>`}

async function hopOnce(){const mn=+S.cfg.hopMin||1,mx=+S.cfg.hopMax||99,h=$("#hInfo");h.textContent="Buscando servidores públicos…";
 try{const l=(await servers(3)).filter(s=>s.playing>=mn&&s.playing<=mx&&s.playing<s.maxPlayers&&!S.visited.includes(s.id));
  h.textContent=`${l.length} servidor(es) válido(s) com ${mn} a ${mx} jogador(es), ainda não visitados.`;
  if(!l.length)return;const s=l[Math.random()*l.length|0];S.visited.push(s.id);if(S.visited.length>500)S.visited.shift();
  S.hist.unshift({t:Date.now(),type:"hop",name:`${s.playing}/${s.maxPlayers} jogadores`,jobId:s.id});S.hist.length=Math.min(S.hist.length,300);store.save();launch(s.id)
 }catch(e){h.textContent="Erro: "+e.message}}
function hopAuto(){const b=$("#hAuto");if(hopT){clearInterval(hopT);hopT=null;b.textContent="Iniciar troca automática";return}
 b.textContent="Interromper troca automática";hopOnce();hopT=setInterval(hopOnce,Math.max(8,S.cfg.hopEvery)*1000)}

function drawSets(){$("#setForm").innerHTML="<h2>Ajustes</h2>"+FIELDS.map(([k,l,t])=>t==="checkbox"?`<label class="row">${l}<input type="checkbox" data-k="${k}" ${S.cfg[k]?"checked":""}></label>`:`<label>${l}<input data-k="${k}" type="${t}" value="${esc(S.cfg[k])}"></label>`).join("")+`<button class="btn" id="sSave">Salvar</button><button class="btn alt" id="sReset">Restaurar padrão</button>`}
async function saveSets(){const c={...S.cfg};for(const[k,,t]of FIELDS){const e=$(`[data-k="${k}"]`);c[k]=t==="checkbox"?e.checked:t==="number"?Number(e.value):e.value.trim()}
 if(c.feedUrl){let u;try{u=new URL(c.feedUrl)}catch{return toast("URL inválida.")}if(u.protocol!=="https:")return toast("Use uma URL https.");
  if(u.origin!=="https://games.roblox.com"&&!(await chrome.permissions.request({origins:[u.origin+"/*"]})))return toast("Permissão de acesso à fonte negada.")}
 S.cfg=c;await store.save();toast("Salvo.");rarKey="";renderList()}

function show(v){$$(".view").forEach(e=>e.classList.toggle("on",e.id===v));$$("#nav button").forEach(b=>b.classList.toggle("on",b.dataset.v===v));if(v==="favs")drawFav();if(v==="hist")drawHist();if(v==="sets")drawSets()}
const find=k=>items.get(k)||S.fav.find(f=>f.key===k);
document.addEventListener("click",async e=>{const t=e.target.closest("button");if(!t)return;const d=t.dataset;
 if(d.v)return show(d.v);
 if(d.sort){if(F.sort===d.sort)F.dir*=-1;else{F.sort=d.sort;F.dir=-1}$$("[data-sort]").forEach(b=>{b.classList.toggle("on",b===t);b.textContent=b.textContent.replace(/ [▲▼]$/,"")+(b===t?(F.dir<0?" ▼":" ▲"):"")});page=1;return renderList()}
 if(d.rar){rarSel.has(d.rar)?rarSel.delete(d.rar):rarSel.add(d.rar);t.classList.toggle("on");page=1;return renderList()}
 if(d.join){const i=find(d.join);return i&&join(i.jobId,i.name)}
 if(d.joinid)return join(d.joinid,"");
 if(d.fav){const i=find(d.fav);if(!i)return;const x=S.fav.findIndex(f=>f.key===i.key);x<0?S.fav.push({...i,isNew:false}):S.fav.splice(x,1);store.save();renderList();if($("#favs").classList.contains("on"))drawFav();return}
 switch(t.id){case"fToggle":$("#fPanel").hidden=!$("#fPanel").hidden;break;case"more":page++;renderList();break;
  case"bStart":start();break;case"bPause":pause();break;case"bReset":pause();items.clear();page=1;rarKey="";renderList();start();break;
  case"hOnce":hopOnce();break;case"hAuto":hopAuto();break;case"hClear":S.hist=[];S.visited=[];store.save();drawHist();toast("Histórico e servidores visitados limpos.");break;
  case"sSave":saveSets();break;case"sReset":S.cfg={...DEF};await store.save();drawSets();toast("Padrões restaurados.")}});
$$("#fPanel input").forEach(i=>i.addEventListener("input",()=>{page=1;renderList()}));
setInterval(()=>$$("[data-t]").forEach(e=>e.textContent=age(+e.dataset.t)),1000);
(async()=>{await store.load();renderList();if(S.cfg.feedUrl&&S.cfg.auto)start();else setLive("parado")})();
